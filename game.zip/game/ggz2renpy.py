#!/usr/bin/env python3.10
import json
import sys
from typing import List, Dict
from enum import Enum
try:
	from translate import Translator
except:
	print("Translate Librady not found")

# Small check if there are enough arguments given
if len(sys.argv) <= 1:
	print("usage: "+sys.argv[0]+" <file.json> <characters_database.json>")
	sys.exit(1)

# List of language in the ggz cutscene interpreter
class LANGUAGES(Enum):
	KEY = 0
	ENGLISH = 1
	CHINESE = 2
	JAPANESE = 3
	ENGLISH_RE = 4
	PORTUGESE = 5
	MTL_CH = 6
	MTL_JA = 7

# Order of the language to extract
langs_to_export = [LANGUAGES.CHINESE,LANGUAGES.JAPANESE,LANGUAGES.ENGLISH_RE,LANGUAGES.PORTUGESE,LANGUAGES.KEY,LANGUAGES.MTL_CH,LANGUAGES.MTL_JA]


def getSpeaker(cmnd, speakerDatabase):
	if cmnd[0]=="speaker":
		speakerID = cmnd[1]
		speaker = speakerDatabase[str(speakerID)]
		speaker = speaker[0] # Gets the english name
	return speaker

def convertMsgOnly_rpy(chapterFull:Dict[str,List], toConvert:str, speakerDatabase:str)->str:
	
	cutscene = chapterFull[toConvert]
	output = ""
	speaker = "Narration" # Default value for speaker
	speaker2 = "Narration" 
	speakerBuffer = ""
	translationBuffer = ""
	if translationTrue:
		translator= Translator(from_lang="zh-CN", to_lang="en")


	for i in range(len(cutscene)):

		cmnd = cutscene[i]
		try:
			cmnd2 = cutscene[i+1]
		except:
			cmnd2 = cutscene[i]
		
		# Try getting future speaker for dim/nodim prediction
		try:
			speaker = getSpeaker(cmnd, speakerDatabase).replace(" ", "_")
		except:
			pass

		try:
			speaker2 = getSpeaker(cmnd2, speakerDatabase).replace(" ", "_")
		except:
			pass

		
		
		if cmnd[0]=="msg":

			# Show character at nodim to talk
			if speakerBuffer != speaker and speaker != "Narration":
				tmp_msg = '    show ' + str(speaker).lower() + ' at nodim\n'
			else:
				tmp_msg = ""
			speakerBuffer = speaker

			# Beginning of the line
			tmp_msg += '\n    tl ' + str(speaker)

			for lang in langs_to_export:

				

				col = lang.value + 1  # +1 because idx 0 is the msg command
				msg = "NONE"

				if col < len(cmnd) and cmnd[col] is not None:

					msg = cmnd[col]

					if lang == LANGUAGES.CHINESE and translationTrue:
						translationBuffer = msg

				if lang == LANGUAGES.MTL_CH and (col>=len(cmnd) or (col < len(cmnd) and cmnd[col] is None)) and translationTrue:
					msg = translator.translate(translationBuffer)

				# The part where we clean the last elements from the parsing
				msg2 = str(msg).replace("\"", "'")
				msg2 = msg2.replace("%", "%%")
				msg2 = msg2.replace("<i>", "{i}")
				msg2 = msg2.replace("</i>", "{/i}")
				
				tmp_msg += " \"" + msg2 + "\n    \""
				
			output += tmp_msg
			output = output[:-6] + "\"\n" # Last line case

			# When speaker finished talking (dim)
			if speaker2 != speaker and speaker != "Narration":
				output += '\n    show ' + str(speaker).lower() + ' at dim\n'
			elif speaker == "Narration":
				output +="\n"

		
	return output


# Opens the database to get the speakers
with open(sys.argv[2], 'r', encoding='utf-8') as f:

	speakerDatabase = json.loads(f.read())

try:
	if sys.argv[3] == "true":
		translationTrue = True
	else:
		translationTrue = False
except:
	translationTrue = False

# Opens the scene data 
with open(sys.argv[1], 'r', encoding='utf-8') as f:
	
	chapterFull = json.loads(f.read())
	
	for k in chapterFull.keys():
		outputTxt = convertMsgOnly_rpy(chapterFull, k, speakerDatabase)
		print(outputTxt)
		ya = open("outputTxt.txt", "w", encoding="utf-8")
		ya.write(outputTxt)
		ya.close()

