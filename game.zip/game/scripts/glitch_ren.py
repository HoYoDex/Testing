"""renpy
init python:
"""
class glitch(renpy.Displayable):
    """
    `randomkey`
        Follows the rules of the random modume's seed function.
        If not set, a random seed is generated when the transform is applied,
        and stays the same afterwards.
        If you want the effect to be random for each render operation, set to None.

    `minbandheight`
        Minimum height of each slice.

    `offset`
        The offset of each slice will be between -offset and offset pixels.

    `nslices`
        Number of slicings to do (the number of slices will be nslices + 1).
        Setting this to 0 is not supported.
        None (the default) makes it random.
    """

    NotSet = object()

    def __init__(self, child, *, randomkey=None, minbandheight=0, offset=5, nslices=170, **properties):
        super().__init__(**properties)
        self.child = renpy.displayable(child)
        if randomkey is self.NotSet:
            randomkey = renpy.random.random()
        self.randomkey = randomkey
        self.minbandheight = minbandheight
        self.offset = offset
        self.nslices = nslices

    def render(self, width, height, st, at):
        child = self.child
        child_render = renpy.render(child, width, height, st, at)
        cwidth, cheight = child_render.get_size()
        if not (cwidth and cheight):
            return child_render
        render = renpy.Render(cwidth, cheight)
        randomobj = renpy.random.Random(self.randomkey)
        offset = self.offset
        minbandheight = self.minbandheight
        nslices = self.nslices
        if nslices is None:
            nslices = min(int(cheight/minbandheight), randomobj.randrange(20, 25))

        theights = sorted(randomobj.randrange(cheight+1) for k in range(nslices)) # y coordinates demarcating all the strips
        offt = 0 # next strip's lateral offset
        fheight = 0 # sum of the size of all the strips added this far
        while fheight<cheight:
            # theight is the height of this particular strip
            if theights:
                theight = max(theights.pop(0)-fheight, minbandheight)
            else:
                theight = cheight-theight

            slice_render = child_render.subsurface((0, fheight, cwidth, theight))
    
            render.blit(slice_render, (offt, round(fheight)))

            fheight += theight
            if offt:
                offt = 0
            else:
                offt = randomobj.randrange(-offset, offset+1)

        return render

    def visit(self):
        return [self.child]
