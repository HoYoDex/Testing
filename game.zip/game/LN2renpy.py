#!/usr/bin/env python3.10
import sys

# Opens the scene data 
with open(sys.argv[1], 'r', encoding='utf-8') as f:
	chinese = f.read().split("\n\n")

# Opens the database to get the speakers
with open(sys.argv[2], 'r', encoding='utf-8') as f:
	english = f.read().split("\n")

output = ""
for i in range(len(chinese)):
	if chinese[i] != "":
		output += '    tl Narration "'+chinese[i].replace("“","").replace("”","")+ '\n    " "NONE\n    " "NONE\n    " "NONE\n    " "NONE\n    " "'+ english[i].replace("\"","").replace("…","...")+'\n    " "NONE"\n\n'

print(output)
ya = open("LNoutput.txt", "w", encoding="utf-8")
ya.write(outputTxt)
ya.close()